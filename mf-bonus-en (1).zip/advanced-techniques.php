<?php require __DIR__ . '/auth.php'; ?>
<?php require __DIR__ . '/templates/advanced-techniques.inc.php';
