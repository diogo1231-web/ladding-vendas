<?php require __DIR__ . '/auth.php'; ?>
<?php require __DIR__ . '/templates/bonus-positions.inc.php';
