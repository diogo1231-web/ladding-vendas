<?php require __DIR__ . '/auth.php'; ?>
<?php require __DIR__ . '/templates/foods-to-avoid.inc.php';
