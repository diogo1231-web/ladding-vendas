<?php require __DIR__ . '/auth.php'; ?>
<?php
// Backwards compatibility: redirect to renamed page
header('Location: aphrodisiac-african-juice.php');
exit;
